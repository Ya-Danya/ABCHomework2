#define _CRT_SECURE_NO_WARNINGS

#include "aphorism.h"
#include "rnd.h";

void aphorism::In(ifstream& ifstr) {
	string str1;
	string str2;
	getline(ifstr, str1);
	getline(ifstr, str2);
	text = str1;
	author = str2;
}

void aphorism::InRnd() {
	text = RandomString();
	author = RandomString();
}

float aphorism::PercentOfPunctuationMarks() {
	int lengthOfString = 0;
	float countOfPunctuations = 0;
	while (text[lengthOfString] != '\0')
	{
		if (text[lengthOfString] == ',' || text[lengthOfString] == '.' ||
			text[lengthOfString] == '?' || text[lengthOfString] == ':' ||
			text[lengthOfString] == '-' || text[lengthOfString] == ';' ||
			text[lengthOfString] == '!') {
			countOfPunctuations += 1.0;
		}
		lengthOfString++;
	}
	return countOfPunctuations / lengthOfString;
}

void aphorism::Out(ofstream& ofstr) {
	ofstr << "Proverb with text:\n" << text << "\nCountry of this proverb:\n" << author << "\nPercent of punctuation marks: " << PercentOfPunctuationMarks() << endl;
}
