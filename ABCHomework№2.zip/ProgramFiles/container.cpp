#include <iostream>
using namespace std;
#include "container.h"

container::container(int s) {
    len = 0;
    size = s;
    storage = new storehouse * [s];
}

container::~container() {
    Clear();
    delete[] storage;
}

void container::Clear() {
    for (int i = 0; i < len; i++) {
        delete storage[i];
    }
    len = 0;
}

void container::In(ifstream& ifstr) {
    while (!ifstr.eof()) {
        if ((storage[len] = storehouse::StaticIn(ifstr)) != 0) {
            len++;
        }
    }
}

void container::InRnd(int s) {
    if (s > size) {
        s = size;
    }
    while (len < s) {
        if ((storage[len] = storehouse::StaticInRnd()) != nullptr) {
            len++;
        }
    }
}

void container::DeletingElements() {
    if (len != 0) {
        double sum = 0;
        for (int i = 0; i < len; ++i) {
            sum += storage[i]->PercentOfPunctuationMarks();
        }
        double average = sum / len;
        int counter = 0;
        for (int i = 0; i < len; ++i) {
            if (storage[i]->PercentOfPunctuationMarks() < average) {
                for (int j = i + 1; j < len; ++j) {
                    storage[j - 1] = storage[j];
                }
                len--;
                i--;
            }
        }
    }
}

void container::Out(ofstream& ofstr) {
    ofstr << "Container contains " << len << " elements." << endl;
    for (int i = 0; i < len; i++) {
        ofstr << i + 1 << ": ";
        storage[i]->Out(ofstr);
    }
}
