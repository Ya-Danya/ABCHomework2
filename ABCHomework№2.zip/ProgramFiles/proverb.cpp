#define _CRT_SECURE_NO_WARNINGS

#include "proverb.h"
#include "rnd.h";

//------------------------------------------------------------------------------

// ���� ���������� ��������� �� �����.
void proverb::In(ifstream& ifstr) {
	string str1;
	string str2;
	getline(ifstr, str1, '\n');
	getline(ifstr, str2, '\n');
	text = str1;
	country = str2;
}

void proverb::InRnd() {
	text = RandomString();
	country = RandomString();
}

float proverb::PercentOfPunctuationMarks() {
	int lengthOfString = 0;
	float countOfPunctuations = 0;
	while (text[lengthOfString] != '\0')
	{
		if (text[lengthOfString] == ',' || text[lengthOfString] == '.' ||
			text[lengthOfString] == '?' || text[lengthOfString] == ':' ||
			text[lengthOfString] == '-' || text[lengthOfString] == ';' ||
			text[lengthOfString] == '!') {
			countOfPunctuations += 1.0;
		}
		lengthOfString++;
	}
	return countOfPunctuations / lengthOfString;
}

void proverb::Out(ofstream& ofstr) {
	ofstr << "Proverb with text:\n" << text << "\nCountry of this proverb:\n" << country << "\nPercent of punctuation marks: " << PercentOfPunctuationMarks() << endl;

}

