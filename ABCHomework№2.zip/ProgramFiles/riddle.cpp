#define _CRT_SECURE_NO_WARNINGS

#include "riddle.h"
#include "rnd.h";


void riddle::In(ifstream& ifstr) {
	string str1;
	string str2;
	getline(ifstr, str1, '\n');
	getline(ifstr, str2, '\n');
	text = str1;
	answer = str2;
}

void riddle::InRnd() {
	text = RandomString();
	answer = RandomString();
}

float riddle::PercentOfPunctuationMarks() {
	int lengthOfString = 0;
	float countOfPunctuations = 0;
	while (text[lengthOfString] != '\0')
	{
		if (text[lengthOfString] == ',' || text[lengthOfString] == '.' ||
			text[lengthOfString] == '?' || text[lengthOfString] == ':' ||
			text[lengthOfString] == '-' || text[lengthOfString] == ';' ||
			text[lengthOfString] == '!') {
			countOfPunctuations += 1.0;
		}
		lengthOfString++;
	}
	return countOfPunctuations / lengthOfString;
}

void riddle::Out(ofstream& ofstr) {
	ofstr << "Proverb with text:\n" << text << "\nCountry of this proverb:\n" << answer << "\nPercent of punctuation marks: " << PercentOfPunctuationMarks() << endl;
}
