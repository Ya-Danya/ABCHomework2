#include "storehouse.h"
#include "aphorism.h"
#include "riddle.h"
#include "proverb.h"

storehouse* storehouse::StaticIn(ifstream& ifstr) {
    storehouse* sh = nullptr;
    int k;
    ifstr >> k;
    switch (k) {
    case 1:
        sh = new aphorism;
        break;
    case 2:
        sh = new riddle;
        break;
    case 3:
        sh = new proverb;
        break;
    default:
        cout << "Incorrect input.";
        exit;
    }
    string newLineCatcher;
    getline(ifstr, newLineCatcher);
    sh->In(ifstr);
    return (sh);
}

storehouse* storehouse::StaticInRnd() {
    storehouse* sh = nullptr;
    int k = RandomType();
    switch (k) {
    case 1:
        sh = new aphorism;
        break;
    case 2:
        sh = new riddle;
        break;
    case 3:
        sh = new proverb;
        break;
    default:
        cout << "Incorrect input.";
        exit;
    }

    sh->InRnd();
    return (sh);
}
